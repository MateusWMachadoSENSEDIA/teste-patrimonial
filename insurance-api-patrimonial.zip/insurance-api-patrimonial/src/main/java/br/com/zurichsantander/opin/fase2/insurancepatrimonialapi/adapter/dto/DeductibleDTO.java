package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DeductibleDTO {

    private String type;

    private String typeAdditionalInfo;

    private AmountDetailsDTO amount;

    private Integer period;

    private String periodicity;

    private String periodCountingMethod;

    private String periodStartDate;

    private String periodEndDate;

    private String description;
}
