package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto;

import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto.enums.IdentificationTypeDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PersonalInfoDTO {

    private String identification;

    private IdentificationTypeDTO identificationType;

    private String name;

    private String postCode;

    private String email;

    private String city;

    private String state;

    private String country;

    private String address;
}
