package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.port.inbound;

import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.InsurancePatrimonial;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.InsurancePatrimonialClaims;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.InsurancePatrimonialPolicyInfo;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.InsurancePatrimonialPremium;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.exceptions.InsurancePatrimonialClaimsNotFoundException;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.exceptions.InsurancePatrimonialPolicyInfoNotFoundException;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.exceptions.InsurancePatrimonialPremiumNotFoundException;

import java.util.List;

public interface InsurancePatrimonialService {

    List<InsurancePatrimonial> allPatrimonialIdentification();

    InsurancePatrimonialPremium getPolicyPremiumByIdOrElseThrowException(String policyId) throws InsurancePatrimonialPremiumNotFoundException;

    InsurancePatrimonialClaims getPolityClaimByIdOrElseThrowException(String policyId) throws InsurancePatrimonialClaimsNotFoundException;

    InsurancePatrimonialPolicyInfo getPolicyInfoByIdOrElseThrowException(String policyId) throws InsurancePatrimonialPolicyInfoNotFoundException;

}
