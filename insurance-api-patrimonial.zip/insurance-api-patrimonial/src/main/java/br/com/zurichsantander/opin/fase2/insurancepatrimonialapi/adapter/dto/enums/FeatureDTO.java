package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto.enums;

public enum FeatureDTO {

    MASSIFICADOS,
    MASSIFICADOS_MICROSEGUROS,
    GRANDES_RISCOS
}
