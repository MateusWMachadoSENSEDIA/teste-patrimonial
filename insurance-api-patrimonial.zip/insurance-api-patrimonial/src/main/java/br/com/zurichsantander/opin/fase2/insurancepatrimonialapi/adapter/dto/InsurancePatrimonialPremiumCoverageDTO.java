package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto;

import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto.enums.InsurancePatrimonialCoverageCodeDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InsurancePatrimonialPremiumCoverageDTO {

    private String branch;

    private InsurancePatrimonialCoverageCodeDTO code;

    private String description;

    private AmountDetailsDTO premiumAmount;
}
