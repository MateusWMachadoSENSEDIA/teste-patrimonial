package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto;

import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.enums.Status;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InsurancePatrimonialClaimsDTO {

    private String policyId;

    private String identification;

    private String documentationDeliveryDate;

    private Status status;

    private String statusAlterationDate;

    private String occurrenceDate;

    private String warningDate;

    private String thirdPartyClaimDate;

    private AmountDetailsDTO amount;

    private String denialJustification;

    private String denialJustificationDescription;

    private List<InsurancePatrimonialClaimCoverageDTO> coverages;
}
