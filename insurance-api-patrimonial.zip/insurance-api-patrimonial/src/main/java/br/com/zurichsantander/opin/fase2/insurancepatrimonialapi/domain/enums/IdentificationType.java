package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.enums;

public enum IdentificationType {

    CPF,
    CNPJ,
    OUTROS
}
