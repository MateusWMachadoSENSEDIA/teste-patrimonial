package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto.enums;

public enum TypeInsuredObjectDTO {

    CONTRATO,
    PROCESSO_ADMINISTRATIVO,
    PROCESSO_JUDICIAL,
    AUTOMOVEL,
    CONDUTOR,
    FROTA,
    OUTROS

}
