package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto;

import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto.enums.TypeInsuredObjectDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InsurancePatrimonialInsuredObjectDTO {

    private String identification;

    private TypeInsuredObjectDTO type;

    private String typeAdditionalInfo;

    private String description;

    private AmountDetailsDTO amount;

    private InsurancePatrimonialInsuredObjectCoverageDTO coverages;
}
