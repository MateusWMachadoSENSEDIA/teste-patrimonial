package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain;

import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.enums.IdentificationType;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.enums.MovementType;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.enums.PaymentType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Payment {

    private String movementDate;

    private MovementType movementType;

    private Long movementPaymentsNumber;

    private AmountDetails amount;

    private String maturityDate;

    private String tellerName;

    private String movementOrigin;

    private String tellerId;

    private IdentificationType tellerIdType;

    private String financialInstitutionCode;

    private PaymentType paymentType;
}
