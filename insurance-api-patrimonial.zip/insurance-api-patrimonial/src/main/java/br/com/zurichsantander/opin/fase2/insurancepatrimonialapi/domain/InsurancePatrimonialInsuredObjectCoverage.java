package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain;

import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.enums.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InsurancePatrimonialInsuredObjectCoverage {

    private String branch;

    private InsurancePatrimonialCoverageCode code;

    private String description;

    private String internalCode;

    private String susepProcessNumber;

    private AmountDetails LMI;

    private Boolean isLMISublimit;

    private String termStartDate;

    private String termEndDate;

    private Boolean isMainCoverage;

    private Feature feature;

    private TypeInsuredObjectCoverage type;

    private String gracePeriod;

    private GracePeriodicity gracePeriodicity;

    private GracePeriodCountingMethod gracePeriodCountingMethod;

    private String gracePeriodStartDate;

    private String gracePeriodEndDate;
}
