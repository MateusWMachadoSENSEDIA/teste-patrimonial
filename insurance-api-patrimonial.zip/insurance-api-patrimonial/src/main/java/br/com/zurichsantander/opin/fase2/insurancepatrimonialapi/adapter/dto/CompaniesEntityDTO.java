package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CompaniesEntityDTO {

    private String companyName;
    private String cnpj;
    private List<String> policies;
}
