package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain;

import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.enums.InsurancePatrimonialCoverageCode;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InsurancePatrimonialClaimCoverage {

    private String insuredObjectId;

    private String branch;

    private InsurancePatrimonialCoverageCode code;

    private String description;

    private String warningDate;

    private String thirdPartyClaimDate;

}
