package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class POSDTO {

    private String applicationType;

    private String description;

    private AmountDetailsDTO minValue;

    private AmountDetailsDTO maxValue;

    private BigDecimal percentage;
}
