package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.enums;

public enum TypeInsuredObject {

    CONTRATO,
    PROCESSO_ADMINISTRATIVO,
    PROCESSO_JUDICIAL,
    AUTOMOVEL,
    CONDUTOR,
    FROTA,
    OUTROS

}
