package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.enums;

public enum PaymentType {

    BOLETO,
    TED,
    TEF,
    CARTAO,
    DOC,
    CHEQUE,
    DESCONTO_EM_FOLHA,
    PIX,
    DINHEIRO_EM_ESPECIE,
    OUTROS

}
