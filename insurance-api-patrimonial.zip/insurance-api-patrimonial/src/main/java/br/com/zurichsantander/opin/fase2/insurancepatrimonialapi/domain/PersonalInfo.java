package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain;

import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.enums.IdentificationType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PersonalInfo {

    private String identification;

    private IdentificationType identificationType;

    private String name;

    private String postCode;

    private String email;

    private String city;

    private String state;

    private String country;

    private String address;
}
