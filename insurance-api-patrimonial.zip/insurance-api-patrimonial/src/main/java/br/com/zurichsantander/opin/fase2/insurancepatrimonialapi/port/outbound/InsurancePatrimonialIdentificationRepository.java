package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.port.outbound;

import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.InsurancePatrimonial;
import com.azure.spring.data.cosmos.repository.CosmosRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface InsurancePatrimonialIdentificationRepository extends CosmosRepository<InsurancePatrimonial, String> {

}
