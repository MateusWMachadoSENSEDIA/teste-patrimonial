package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class InsurancePatrimonialPolicyInfoNotFoundException extends Exception{

    public InsurancePatrimonialPolicyInfoNotFoundException(String policyId) {
        super("Policy Info not found with policy id" + policyId);
    }
}
