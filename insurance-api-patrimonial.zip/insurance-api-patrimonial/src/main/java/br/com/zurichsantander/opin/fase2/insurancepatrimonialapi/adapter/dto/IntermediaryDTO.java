package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto;

import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto.enums.IdentificationTypeDTO;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto.enums.TypeDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class IntermediaryDTO {

    private TypeDTO type;

    private String identification;

    private String brokerId;

    private IdentificationTypeDTO identificationType;

    private String name;

    private String postCode;

    private String email;

    private String city;

    private String state;

    private String country;

    private String address;
}
