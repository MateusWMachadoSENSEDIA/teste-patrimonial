package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.enums;

public enum IssuanceType {

    EMISSAO_PROPRIA,
    COSSEGURO_ACEITO
}
