package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain;

import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.enums.TypeInsuredObject;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InsurancePatrimonialInsuredObject {

    private String identification;

    private TypeInsuredObject type;

    private String typeAdditionalInfo;

    private String description;

    private AmountDetails amount;

    private InsurancePatrimonialInsuredObjectCoverage coverages;

}
