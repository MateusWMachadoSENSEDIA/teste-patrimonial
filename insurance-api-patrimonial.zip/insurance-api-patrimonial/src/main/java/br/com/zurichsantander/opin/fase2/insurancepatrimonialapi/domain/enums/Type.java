package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.enums;

public enum Type {

    CORRETOR,
    REPRESENTANTE,
    ESTIPULANTE,
    CORRESPONDENTE,
    AGENTE_DE_MICROSSEGUROS,
    OUTROS

}
