package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.enums;

public enum Feature {

    MASSIFICADOS,
    MASSIFICADOS_MICROSEGUROS,
    GRANDES_RISCOS
}
