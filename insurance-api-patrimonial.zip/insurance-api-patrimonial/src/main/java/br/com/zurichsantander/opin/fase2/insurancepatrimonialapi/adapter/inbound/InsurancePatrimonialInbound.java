package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.inbound;

import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto.InsurancePatrimonialClaimsDTO;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto.InsurancePatrimonialDTO;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto.InsurancePatrimonialPolicyInfoDTO;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto.InsurancePatrimonialPremiumDTO;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.outbound.InsurancePatrimonialOutbound;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.exceptions.InsurancePatrimonialClaimsNotFoundException;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.exceptions.InsurancePatrimonialPolicyInfoNotFoundException;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.exceptions.InsurancePatrimonialPremiumNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/open-insurance/insurance-patrimonial/v1")
public class InsurancePatrimonialInbound {

    @Autowired
    private InsurancePatrimonialOutbound insurancePatrimonialOutbound;

    @GetMapping("/")
    public ResponseEntity<List<InsurancePatrimonialDTO>> getAllInsurancePatrimonial() {
        return insurancePatrimonialOutbound.getAllInsurancePatrimonial();
    }

    @GetMapping("/{policyId}/policy-info")
    public ResponseEntity<InsurancePatrimonialPolicyInfoDTO> getPolicyInfoById(@PathVariable String policyId) throws InsurancePatrimonialPolicyInfoNotFoundException {
        return insurancePatrimonialOutbound.getPolicyInfoById(policyId);
    }

    @GetMapping("/{policyId}/premium")
    public ResponseEntity<InsurancePatrimonialPremiumDTO> getPolicyPremiumById(@PathVariable String policyId) throws InsurancePatrimonialPremiumNotFoundException {
        return insurancePatrimonialOutbound.getPolicyPremiumById(policyId);
    }

    @GetMapping("/{policyId}/claim")
    public ResponseEntity<InsurancePatrimonialClaimsDTO> getPolityClaimById(@PathVariable String policyId) throws InsurancePatrimonialClaimsNotFoundException {
        return insurancePatrimonialOutbound.getPolityClaimById(policyId);
    }

}
