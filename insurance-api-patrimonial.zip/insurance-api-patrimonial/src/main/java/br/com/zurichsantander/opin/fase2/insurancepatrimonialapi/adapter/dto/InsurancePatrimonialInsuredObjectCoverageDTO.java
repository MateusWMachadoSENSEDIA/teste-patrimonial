package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto;

import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto.enums.GracePeriodCountingMethodDTO;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto.enums.GracePeriodicityDTO;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto.enums.InsurancePatrimonialCoverageCodeDTO;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto.enums.TypeInsuredObjectCoverageDTO;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.enums.Feature;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InsurancePatrimonialInsuredObjectCoverageDTO {

    private String branch;

    private InsurancePatrimonialCoverageCodeDTO code;

    private String description;

    private String internalCode;

    private String susepProcessNumber;

    private AmountDetailsDTO LMI;

    private Boolean isLMISublimit;

    private String termStartDate;

    private String termEndDate;

    private Boolean isMainCoverage;

    private Feature feature;

    private TypeInsuredObjectCoverageDTO type;

    private String gracePeriod;

    private GracePeriodicityDTO gracePeriodicity;

    private GracePeriodCountingMethodDTO gracePeriodCountingMethod;

    private String gracePeriodStartDate;

    private String gracePeriodEndDate;
}
