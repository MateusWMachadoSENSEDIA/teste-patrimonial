package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InsurancePatrimonialPremiumDTO {

    private String policyId;

    private Long paymentsQuantity;

    private AmountDetailsDTO amount;

    private List<InsurancePatrimonialPremiumCoverageDTO> coverages;

    private List<PaymentDTO> payments;
}
