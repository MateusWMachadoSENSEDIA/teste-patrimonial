package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.port.outbound;

import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.InsurancePatrimonialClaims;
import com.azure.spring.data.cosmos.repository.CosmosRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface InsurancePatrimonialClaimsRepository extends CosmosRepository<InsurancePatrimonialClaims, String> {

    Optional<InsurancePatrimonialClaims> findByPolicyId(String policyId);
}
