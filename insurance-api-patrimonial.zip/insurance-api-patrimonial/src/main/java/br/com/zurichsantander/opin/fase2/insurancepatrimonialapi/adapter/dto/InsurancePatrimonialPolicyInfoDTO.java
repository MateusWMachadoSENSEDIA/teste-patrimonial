package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto;

import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto.enums.IssuanceTypeDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InsurancePatrimonialPolicyInfoDTO {

    private String documentType;

    private String policyId;

    private String susepProcessNumber;

    private String groupCertificateId;

    private IssuanceTypeDTO issuanceType;

    private String issuanceDate;

    private String termStartDate;

    private String termEndDate;

    private String leadInsurerCode;

    private String leadInsurerPolicyId;

    private AmountDetailsDTO maxLMG;

    private String proposalId;

    private List<PersonalInfoDTO> insureds;

    private List<BeneficiaryInfoDTO> beneficiaries;

    private List<PersonalInfoDTO> principals;

    private List<IntermediaryDTO> intermediaries;

    private List<InsurancePatrimonialInsuredObjectDTO> insuredObjects;

    private List<InsurancePatrimonialCoverageDTO> coverages;

    private String coinsuranceRetainedPercentage;

    private List<CoinsurerDTO> consurers;

    private InsurancePatrimonialSpecificPolicyInfoDTO branchInfo;
}
