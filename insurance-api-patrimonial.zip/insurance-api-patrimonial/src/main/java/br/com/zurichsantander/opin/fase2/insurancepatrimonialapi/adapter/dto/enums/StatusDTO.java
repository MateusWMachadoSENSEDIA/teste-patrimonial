package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto.enums;

import lombok.Getter;

@Getter
public enum StatusDTO {

    ABERTO("ABERTO"),
    ENCERRADO_COM_INDENIZACAO("ENCERRADO_COM_INDENIZACAO"),
    ENCERRADO_SEM_INDENIZACAO("ENCERRADO_SEM_INDENIZACAO"),
    REABERTO("REABERTO"),
    CANCELADO_POR_ERRO_OPERACIONAL("CANCELADO_POR_ERRO_OPERACIONAL"),
    AVALIACAO_INICIAL("AVALIACAO_INICIAL");

    private final String status;
    StatusDTO(String status) {
        this.status = status;
    }


}
