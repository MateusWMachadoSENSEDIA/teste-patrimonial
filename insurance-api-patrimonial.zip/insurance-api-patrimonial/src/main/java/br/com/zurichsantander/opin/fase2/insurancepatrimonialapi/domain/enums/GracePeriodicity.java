package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.enums;

public enum GracePeriodicity {

    DIA,
    MES,
    ANO

}
