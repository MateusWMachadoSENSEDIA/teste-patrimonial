package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.outbound;

import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto.InsurancePatrimonialClaimsDTO;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto.InsurancePatrimonialDTO;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto.InsurancePatrimonialPolicyInfoDTO;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto.InsurancePatrimonialPremiumDTO;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.InsurancePatrimonialClaims;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.InsurancePatrimonialPolicyInfo;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.InsurancePatrimonialPremium;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.exceptions.InsurancePatrimonialClaimsNotFoundException;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.exceptions.InsurancePatrimonialPolicyInfoNotFoundException;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.exceptions.InsurancePatrimonialPremiumNotFoundException;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.port.inbound.InsurancePatrimonialService;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@AllArgsConstructor(onConstructor = @__(@Autowired))
@Component
public class InsurancePatrimonialOutbound {
    private InsurancePatrimonialService insurancePatrimonialService;

    private ModelMapper mapper;

    public ResponseEntity<List<InsurancePatrimonialDTO>> getAllInsurancePatrimonial() {
        List<InsurancePatrimonialDTO> collect = insurancePatrimonialService.allPatrimonialIdentification().
                stream()
                .map(patrimonialIdentification -> mapper.map(patrimonialIdentification, InsurancePatrimonialDTO.class))
                .collect(Collectors.toList());

        return ResponseEntity.ok(collect);
    }

    public ResponseEntity<InsurancePatrimonialPolicyInfoDTO> getPolicyInfoById(String policyId) throws InsurancePatrimonialPolicyInfoNotFoundException {
        InsurancePatrimonialPolicyInfo foundedInsurancePolicyInfo = insurancePatrimonialService.getPolicyInfoByIdOrElseThrowException(policyId);

        return ResponseEntity.ok(mapper.map(foundedInsurancePolicyInfo, InsurancePatrimonialPolicyInfoDTO.class));
    }

    public ResponseEntity<InsurancePatrimonialPremiumDTO> getPolicyPremiumById(String policyId) throws InsurancePatrimonialPremiumNotFoundException {
        InsurancePatrimonialPremium foundedInsurancePatrimonialPremium = insurancePatrimonialService.getPolicyPremiumByIdOrElseThrowException(policyId);

        return ResponseEntity.ok(mapper.map(foundedInsurancePatrimonialPremium, InsurancePatrimonialPremiumDTO.class));
    }

    public ResponseEntity<InsurancePatrimonialClaimsDTO> getPolityClaimById(String policyId) throws InsurancePatrimonialClaimsNotFoundException {
        InsurancePatrimonialClaims foundedInsurancePatrimonialClaims = insurancePatrimonialService.getPolityClaimByIdOrElseThrowException(policyId);

        return ResponseEntity.ok(mapper.map(foundedInsurancePatrimonialClaims, InsurancePatrimonialClaimsDTO.class));
    }

}
