package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.port.outbound;

import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.InsurancePatrimonialPolicyInfo;
import com.azure.spring.data.cosmos.repository.CosmosRepository;

import java.util.Optional;

public interface InsurancePatrimonialPolicyInfoRepository extends CosmosRepository<InsurancePatrimonialPolicyInfo, String> {

    Optional<InsurancePatrimonialPolicyInfo> findByPolicyId(String policyId);
}
