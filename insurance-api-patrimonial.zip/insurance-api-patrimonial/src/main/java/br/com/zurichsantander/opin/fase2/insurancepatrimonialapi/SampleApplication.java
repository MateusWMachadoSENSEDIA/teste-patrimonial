package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi;

import com.azure.spring.data.cosmos.repository.config.EnableCosmosRepositories;
import com.azure.spring.data.cosmos.repository.config.EnableReactiveCosmosRepositories;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Locale;

@SpringBootApplication
@EnableCosmosRepositories
@EnableReactiveCosmosRepositories
public class SampleApplication {

    public static void main(String[] args) {
        Locale.setDefault(Locale.US);
        System.setProperty("javax.net.ssl.trustStore","/usr/lib/jvm/jdk-11.0.16_linux-x64_bin/jdk-11.0.16/lib/security/cacerts");
        System.setProperty("javax.net.ssl.trustStorePassword","changeit");

        SpringApplication.run(SampleApplication.class, args);
    }


}
