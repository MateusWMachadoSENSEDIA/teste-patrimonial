package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain;

import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.enums.IssuanceType;
import com.azure.spring.data.cosmos.core.mapping.Container;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;

import java.util.List;

@Container(containerName = "patrimonial_policy_info", ru = "400")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class InsurancePatrimonialPolicyInfo {

    private String documentType;

    @Id
    private String policyId;

    private String susepProcessNumber;

    private String groupCertificateId;

    private IssuanceType issuanceType;

    private String issuanceDate;

    private String termStartDate;

    private String termEndDate;

    private String leadInsurerCode;

    private String leadInsurerPolicyId;

    private AmountDetails maxLMG;

    private String proposalId;

    private List<PersonalInfo> insureds;

    private List<BeneficiaryInfo> beneficiaries;

    private List<PersonalInfo> principals;

    private List<Intermediary> intermediaries;

    private List<InsurancePatrimonialInsuredObject> insuredObjects;

    private List<InsurancePatrimonialCoverage> coverages;

    private String coinsuranceRetainedPercentage;

    private List<Coinsurer> consurers;

    private InsurancePatrimonialSpecificPolicyInfo branchInfo;



}
