package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain;

import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.enums.PropertyType;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.enums.StructuringType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InsurancePatrimonialSpecificInsuredObject {

    private String identification;

    private PropertyType propertyType;

    private StructuringType structuringType;

    private String postCode;

    private String businessActivity;
}
