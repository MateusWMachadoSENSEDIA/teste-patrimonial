package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto;

import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto.enums.PropertyTypeDTO;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto.enums.StructuringTypeDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InsurancePatrimonialSpecificInsuredObjectDTO {

    private String identification;

    private PropertyTypeDTO propertyType;

    private StructuringTypeDTO structuringType;

    private String postCode;

    private String businessActivity;
}
