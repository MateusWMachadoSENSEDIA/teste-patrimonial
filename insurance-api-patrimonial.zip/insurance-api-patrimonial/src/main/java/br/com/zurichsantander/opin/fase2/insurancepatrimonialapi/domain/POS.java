package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class POS {

    private String applicationType;

    private String description;

    private AmountDetails minValue;

    private AmountDetails maxValue;

    private BigDecimal percentage;
}
