package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.port.outbound;

import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.InsurancePatrimonialPremium;
import com.azure.spring.data.cosmos.repository.CosmosRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface InsurancePatrimonialPremiumRepository extends CosmosRepository<InsurancePatrimonialPremium, String> {

    Optional<InsurancePatrimonialPremium> findByPolicyId(String policyId);
}
