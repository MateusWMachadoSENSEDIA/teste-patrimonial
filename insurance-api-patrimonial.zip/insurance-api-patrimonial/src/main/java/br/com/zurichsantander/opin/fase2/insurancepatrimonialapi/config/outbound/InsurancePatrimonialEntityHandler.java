package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.config.outbound;

import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.exceptions.InsurancePatrimonialClaimsNotFoundException;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.exceptions.InsurancePatrimonialPolicyInfoNotFoundException;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.exceptions.InsurancePatrimonialPremiumNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class InsurancePatrimonialEntityHandler {

    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(InsurancePatrimonialPremiumNotFoundException.class)
    public String handleInsurancePatrimonialPremiumNotFoundException(InsurancePatrimonialPremiumNotFoundException exception) {
        return exception.getLocalizedMessage();
    }

    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(InsurancePatrimonialPolicyInfoNotFoundException.class)
    public String handleInsurancePatrimonialPolicyInfoNotFoundException(InsurancePatrimonialPolicyInfoNotFoundException exception) {
        return exception.getLocalizedMessage();
    }

    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(InsurancePatrimonialClaimsNotFoundException.class)
    public String handleInsurancePatrimonialClaimsNotFoundException(InsurancePatrimonialClaimsNotFoundException exception) {
        return exception.getLocalizedMessage();
    }


}
