package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain;

import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.enums.Status;
import com.azure.spring.data.cosmos.core.mapping.Container;
import com.azure.spring.data.cosmos.core.mapping.PartitionKey;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;

import java.util.List;

@Container(containerName = "patrimonial_policy_claim", ru = "400")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class InsurancePatrimonialClaims {

    @Id
    private String id;

    @PartitionKey
    private String policyId;

    private String identification;

    private String documentationDeliveryDate;

    private Status status;

    private String statusAlterationDate;

    private String occurrenceDate;

    private String warningDate;

    private String thirdPartyClaimDate;

    private AmountDetails amount;

    private String denialJustification;

    private String denialJustificationDescription;

    private List<InsurancePatrimonialClaimCoverage> coverages;

}
