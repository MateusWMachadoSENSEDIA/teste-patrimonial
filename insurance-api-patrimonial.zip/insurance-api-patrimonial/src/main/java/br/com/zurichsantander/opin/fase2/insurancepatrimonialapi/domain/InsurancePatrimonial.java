package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain;

import com.azure.spring.data.cosmos.core.mapping.Container;
import com.azure.spring.data.cosmos.core.mapping.GeneratedValue;
import com.azure.spring.data.cosmos.core.mapping.PartitionKey;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;

import java.util.List;

@Container(containerName = "patrimonial_identification", ru = "400")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class InsurancePatrimonial {

    @Id
    @PartitionKey
    @GeneratedValue
    private String id;

    private String brand;
    private List<CompaniesEntity> companies;

    @Override
    public String toString() {
        return "PatrimonialIdentificationEntity{" +
                "id='" + id + '\'' +
                ", brand='" + brand + '\'' +
                ", companiesEntityList=" + companies +
                '}';
    }
}
