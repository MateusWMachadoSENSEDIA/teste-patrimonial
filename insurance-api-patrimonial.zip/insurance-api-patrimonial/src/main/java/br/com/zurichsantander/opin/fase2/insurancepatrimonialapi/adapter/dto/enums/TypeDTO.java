package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto.enums;

public enum TypeDTO {

    CORRETOR,
    REPRESENTANTE,
    ESTIPULANTE,
    CORRESPONDENTE,
    AGENTE_DE_MICROSSEGUROS,
    OUTROS

}
