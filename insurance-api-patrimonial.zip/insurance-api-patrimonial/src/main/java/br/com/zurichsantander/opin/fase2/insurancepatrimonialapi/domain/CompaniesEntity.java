package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CompaniesEntity {

    private String companyName;

    private String cnpj;

    private List<String> policies;

}
