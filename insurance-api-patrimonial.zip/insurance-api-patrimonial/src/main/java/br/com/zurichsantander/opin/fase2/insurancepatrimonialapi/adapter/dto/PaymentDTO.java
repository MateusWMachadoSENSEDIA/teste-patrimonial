package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto;

import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto.enums.IdentificationTypeDTO;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto.enums.MovementTypeDTO;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto.enums.PaymentTypeDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PaymentDTO {

    private String movementDate;

    private MovementTypeDTO movementType;

    private Long movementPaymentsNumber;

    private AmountDetailsDTO amount;

    private String maturityDate;

    private String tellerName;

    private String movementOrigin;

    private String tellerId;

    private IdentificationTypeDTO tellerIdType;

    private String financialInstitutionCode;

    private PaymentTypeDTO paymentType;
}
