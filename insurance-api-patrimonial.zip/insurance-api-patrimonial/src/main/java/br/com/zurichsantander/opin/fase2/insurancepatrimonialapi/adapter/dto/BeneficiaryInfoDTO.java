package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto;

import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto.enums.IdentificationTypeDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BeneficiaryInfoDTO {

    private String identification;

    private IdentificationTypeDTO identificationType;

    private String name;
}
