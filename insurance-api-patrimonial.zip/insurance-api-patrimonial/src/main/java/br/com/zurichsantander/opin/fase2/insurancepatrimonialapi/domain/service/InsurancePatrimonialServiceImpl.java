package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.service;

import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.InsurancePatrimonial;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.InsurancePatrimonialClaims;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.InsurancePatrimonialPolicyInfo;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.InsurancePatrimonialPremium;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.exceptions.InsurancePatrimonialClaimsNotFoundException;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.exceptions.InsurancePatrimonialPolicyInfoNotFoundException;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.exceptions.InsurancePatrimonialPremiumNotFoundException;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.port.inbound.InsurancePatrimonialService;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.port.outbound.InsurancePatrimonialClaimsRepository;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.port.outbound.InsurancePatrimonialIdentificationRepository;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.port.outbound.InsurancePatrimonialPolicyInfoRepository;
import br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.port.outbound.InsurancePatrimonialPremiumRepository;
import com.azure.cosmos.implementation.NotFoundException;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor(onConstructor = @__(@Autowired))
public class InsurancePatrimonialServiceImpl implements InsurancePatrimonialService {

    private final Logger logger = LoggerFactory.getLogger(InsurancePatrimonialServiceImpl.class);

    private InsurancePatrimonialIdentificationRepository insurancePatrimonialIdentificationRepository;

    private InsurancePatrimonialPremiumRepository insurancePatrimonialPremiumRepository;

    private InsurancePatrimonialClaimsRepository insurancePatrimonialClaimsRepository;

    private InsurancePatrimonialPolicyInfoRepository insurancePatrimonialPolicyInfoRepository;

    @Override
    public List<InsurancePatrimonial> allPatrimonialIdentification() {
        List<InsurancePatrimonial> listOfAllPatrimonialIdentification = new ArrayList<>();
        insurancePatrimonialIdentificationRepository.findAll().forEach(listOfAllPatrimonialIdentification::add);
        if (listOfAllPatrimonialIdentification.isEmpty()) {
            throw new NotFoundException();
        }
        logger.info("UserServiceImpl.allPatrimonialIdentification - end - founded entities: [{}]", listOfAllPatrimonialIdentification);
        return listOfAllPatrimonialIdentification;
    }

    @Override
    public InsurancePatrimonialPremium getPolicyPremiumByIdOrElseThrowException(String policyId) throws InsurancePatrimonialPremiumNotFoundException {
        Optional<InsurancePatrimonialPremium> optionalPolicyPremium = insurancePatrimonialPremiumRepository.findByPolicyId(policyId);
        logger.info("UserServiceImpl.getPolicyPremiumByIdOrElseThrowException - end - founded entity: [{}]", optionalPolicyPremium.toString());
        return optionalPolicyPremium.orElseThrow(() -> new InsurancePatrimonialPremiumNotFoundException(policyId));
    }

    @Override
    public InsurancePatrimonialClaims getPolityClaimByIdOrElseThrowException(String policyId) throws InsurancePatrimonialClaimsNotFoundException {
        Optional<InsurancePatrimonialClaims> optionalPolicyClaim = insurancePatrimonialClaimsRepository.findByPolicyId(policyId);
        logger.info("UserServiceImpl.getPolityClaimByIdOrElseThrowException - end - founded entity: [{}]", optionalPolicyClaim.toString());
        return optionalPolicyClaim.orElseThrow(() -> new InsurancePatrimonialClaimsNotFoundException(policyId));
    }

    @Override
    public InsurancePatrimonialPolicyInfo getPolicyInfoByIdOrElseThrowException(String policyId) throws InsurancePatrimonialPolicyInfoNotFoundException {
        Optional<InsurancePatrimonialPolicyInfo> optionalPolicyInfo = insurancePatrimonialPolicyInfoRepository.findByPolicyId(policyId);
        logger.info("UserServiceImpl.getPolicyInfoByIdOrElseThrowException - end - founded entity: [{}]", optionalPolicyInfo.toString());
        return optionalPolicyInfo.orElseThrow(() -> new InsurancePatrimonialPolicyInfoNotFoundException(policyId));

    }

}
