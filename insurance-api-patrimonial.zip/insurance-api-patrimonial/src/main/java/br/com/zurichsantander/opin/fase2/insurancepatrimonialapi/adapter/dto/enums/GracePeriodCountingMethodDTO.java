package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto.enums;

public enum GracePeriodCountingMethodDTO {

    DIAS_UTEIS,
    DIAS_CORRIDOS

}
