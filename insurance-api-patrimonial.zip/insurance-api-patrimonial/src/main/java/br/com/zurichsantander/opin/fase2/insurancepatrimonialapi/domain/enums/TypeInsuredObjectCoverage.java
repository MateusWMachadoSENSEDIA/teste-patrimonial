package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain.enums;

public enum TypeInsuredObjectCoverage {

    PARAMETRICO,
    INTERMITENTE,
    REGULAR_COMUM,
    CAPITAL_GLOBAL,
    PARAMETRICO_E_INTERMITENTE

}
