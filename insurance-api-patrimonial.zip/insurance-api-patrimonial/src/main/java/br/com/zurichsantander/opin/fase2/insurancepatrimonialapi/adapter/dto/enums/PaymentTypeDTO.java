package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto.enums;

public enum PaymentTypeDTO {

    BOLETO,
    TED,
    TEF,
    CARTAO,
    DOC,
    CHEQUE,
    DESCONTO_EM_FOLHA,
    PIX,
    DINHEIRO_EM_ESPECIE,
    OUTROS

}
