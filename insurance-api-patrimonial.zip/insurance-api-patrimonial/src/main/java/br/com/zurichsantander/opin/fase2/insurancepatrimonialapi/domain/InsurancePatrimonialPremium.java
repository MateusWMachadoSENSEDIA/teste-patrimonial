package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.domain;

import com.azure.spring.data.cosmos.core.mapping.Container;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;

import java.util.List;

@Container(containerName = "patrimonial_policy_premium", ru = "400")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class InsurancePatrimonialPremium {

    @Id
    private String policyId;

    private Long paymentsQuantity;

    private AmountDetails amount;

    private List<InsurancePatrimonialPremiumCoverage> coverages;

    private List<Payment> payments;

}
