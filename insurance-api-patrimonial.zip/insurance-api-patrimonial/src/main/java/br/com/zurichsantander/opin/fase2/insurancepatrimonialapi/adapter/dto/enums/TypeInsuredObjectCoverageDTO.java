package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto.enums;

public enum TypeInsuredObjectCoverageDTO {

    PARAMETRICO,
    INTERMITENTE,
    REGULAR_COMUM,
    CAPITAL_GLOBAL,
    PARAMETRICO_E_INTERMITENTE

}
