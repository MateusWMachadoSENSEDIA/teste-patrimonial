package br.com.zurichsantander.opin.fase2.insurancepatrimonialapi.adapter.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InsurancePatrimonialDTO {

    private String id;
    private String brand;
    private List<CompaniesEntityDTO> companies;
}
